import React, { useState } from "react";

const PersonCard = (props) => {
  const { firstName, lastName, age, hair } = props; //creates properties (props) for each PersonCard. Blueprint.
  const [stateAge, setStateAge] = useState(age); //useState hook to set initial value
  return (
    <div>
      <h2>
        {lastName}, {firstName}
      </h2>
      <h4>Age: {stateAge}</h4>
      <h4>Hair: {hair}</h4>
      <button onClick={() => setStateAge(stateAge + 1)}>
        Birthday button for {firstName} {lastName}
      </button>
    </div>
  );
};

export default PersonCard;
