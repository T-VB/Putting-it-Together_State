import "./App.css";
import PersonCard from "./components/PersonCard";

const personCardArr = [
  {
    //***MAKE SURE all values are set correctly, string vs int, etc. (age)***
    firstName: "Ken",
    lastName: "Griffey Jr",
    age: 21,
    hair: "black",
  },
  {
    firstName: "Julio",
    lastName: "Rodriguez",
    age: 31,
    hair: "black",
  },
  {
    firstName: "Felix",
    lastName: "Hernandez",
    age: 34,
    hair: "black",
  },
  {
    firstName: "Ichiro",
    lastName: "Suzuki",
    age: 47,
    hair: "black",
  },
];

function App() {
  return (
    <div className="App">
      {personCardArr.map(
        //.map function iterates through an array
        (personObject, index) => (
          //personObject used to hold info from each personcard as an object
          <PersonCard
            key={index}
            firstName={personObject.firstName}
            lastName={personObject.lastName}
            age={personObject.age}
            hair={personObject.hair}
          />
        )
      )}

      {/* <PersonCard
        firstName={"Ken"}
        lastName={"Griffey Jr"}
        age={"31"}
        hair={"black"}
      />
      <PersonCard
        firstName={"Julio"}
        lastName={"Rodriguez"}
        age={"21"}
        hair={"black"}
      />
      <PersonCard
        firstName={"Felix"}
        lastName={"Hernandez"}
        age={"34"}
        hair={"dyed yellow"}
      />
      <PersonCard
        firstName={"Ichiro"}
        lastName={"Suzuki"}
        age={"47"}
        hair={"black"}
      /> */}
    </div>
  );
}

export default App;
